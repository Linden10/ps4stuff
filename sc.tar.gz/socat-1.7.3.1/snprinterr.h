/* source: snprinterr.h */
/* Copyright Gerhard Rieger */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __snprinterr_h_included
#define __snprinterr_h_included 1

int snprinterr(char *str, size_t size, const char *format);

#endif /* !defined(__snprinterr_h_included) */
